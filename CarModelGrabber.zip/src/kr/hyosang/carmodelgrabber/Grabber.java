package kr.hyosang.carmodelgrabber;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.google.gson.Gson;

import kr.hyosang.carmodelgrabber.vo.EncarComboData;


public class Grabber extends Thread {
	private Gson mGson = new Gson();
	
	@Override
	public void run() {
		FileOutputStream fos = null;
		
		try {
			fos = new FileOutputStream("cardb.txt");
			
			String companyList = getWebResource("http://www.encar.com/common/combo/cardbcompany.json?method=carList", true, "carType=&_=");
			EncarComboData [] companies = mGson.fromJson(companyList, EncarComboData[].class);
			
			for(EncarComboData c : companies) {
				System.out.println("������ : " + c.label);
				
				String modelgList = getWebResource("http://www.encar.com/common/combo/modelgroupfordb.json?method=carList", true, "mnfccd=" + c.abbreviation + "&_=");
				EncarComboData [] modelgroups = mGson.fromJson(modelgList, EncarComboData[].class);
				
				for(EncarComboData mg : modelgroups) {
					String modelList = getWebResource("http://www.encar.com/common/combo/cardbmodel.json?method=carList", true, "mnfccd=" + c.abbreviation + "&mdlgroupcd=" + mg.abbreviation + "&_=");
					EncarComboData [] models = mGson.fromJson(modelList, EncarComboData[].class);
					
					for(EncarComboData m : models) {
						System.out.println("�� : " + m.label);
						
						String yearList = getWebResource("http://www.encar.com/common/combo/jatoYr.json?method=carList", true, "mnfccd=" + c.abbreviation + "&mdlcd=" + m.abbreviation + "&valueType%3A=name&_=");
						EncarComboData [] years = mGson.fromJson(yearList, EncarComboData[].class);
						
						for(EncarComboData y : years) {
							//���
							String gradeList = getWebResource("http://www.encar.com/common/combo/carDbGradeHead_new.json?method=carList&caryear=" + y.abbreviation, true,
									String.format("mnfccd=%s&mdlcd=%s&year=%s&valueType=%%3A=name&_=", c.abbreviation, m.abbreviation, y.abbreviation));
							EncarComboData [] grades = mGson.fromJson(gradeList, EncarComboData[].class);
							
							for(EncarComboData grade : grades) {
								//���ε��
								String detailedGradeList = getWebResource("http://www.encar.com/common/combo/carDbGradeDetail_new.json?method=carList&caryear=" + y.abbreviation, true,
										String.format("mnfccd=%s&mdlcd=%s&clsheadcd=%s&year=%s&valueType%%3A=name&_=", c.abbreviation, m.abbreviation, grade.abbreviation, y.abbreviation));
								EncarComboData [] detailGrades = mGson.fromJson(detailedGradeList, EncarComboData[].class);
								
								if(detailGrades.length > 0) {
									for(EncarComboData detailGrade : detailGrades) {
										String line = String.format("%s^%s^%s^%s^%s %s\n", c.label, mg.label, m.label, y.label, grade.label, detailGrade.label);
										fos.write(line.getBytes("UTF-8"));
									}
								}else {
									String line = String.format("%s^%s^%s^%s^%s\n", c.label, mg.label, m.label, y.label, grade.label);
									fos.write(line.getBytes("UTF-8"));
								}
							}	//��� loop
						}	//���� loop
					}	//�� loop
					
					
					Thread.sleep(2000);
				}	//�𵨺з� loop
				
				Thread.sleep(5000);
			}	//������ loop
			
		}catch(MalformedURLException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}finally {
			if(fos != null) { try { fos.close(); } catch(IOException e) { e.printStackTrace(); } }
		}
	}
	
	
	
	private String getWebResource(String url, boolean bPost, String postParams) throws IOException, MalformedURLException {
		URL urlObj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();

		if(bPost) {
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
		}else {
			conn.setRequestMethod("GET");
			conn.setDoOutput(false);
		}
		
		conn.setDoInput(true);
		
		if(bPost) {
			OutputStream os = conn.getOutputStream();
			os.write(postParams.getBytes("US-ASCII"));
			os.flush();
		}else {
			conn.connect();
		}
		
		char [] buf = new char[1024];
		int nRead;
		InputStreamReader reader = new InputStreamReader(conn.getInputStream(), "EUC-KR");
		StringBuffer sb = new StringBuffer();
		
		while((nRead = reader.read(buf)) > 0) {
			sb.append(new String(buf, 0, nRead));
		}
		
		return sb.toString();
	}
}
