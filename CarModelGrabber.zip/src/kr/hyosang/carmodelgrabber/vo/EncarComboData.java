package kr.hyosang.carmodelgrabber.vo;

public class EncarComboData {
	public int maxcnt;
	public int count;
	public String cscd;
	public String groupyn;
	public String label;
	public String abbreviation;
	public String type;
	public String expl;
	public String pure;
	public String vl2;
	public String group_nm;
	public String vl1;
	public String name;

}
