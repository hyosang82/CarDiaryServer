package kr.hyosang.carmodelgrabber;

public class GrabberMain {
	
	public static final void main(String [] args) {
		Grabber g = new Grabber();
		g.start();
	}
}
